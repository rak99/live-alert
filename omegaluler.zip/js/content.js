// Add keyword mode, where extension looks ONLY for keywords, for example : NO, WHO
// change this line : if (lowerCaseElt.indexOf('o') > -1) {
// To a no boundary regular expression with the keyword

// TODO:
/**
 * When paragraph has a carrot in it e.g: "<OMEGA" or ">OMEGA"
 * There is a loop of images spawning in that paragraph, fix it, it's because it's inserting <<img or something and if it's after />>
 * The O in OMEGA stays there
 */

let imges = ["<img src='https://cdn.frankerfacez.com/emoticon/295799/1'></img>", "<img src='https://i.imgur.com/zOQUJ3l.png'></img>"]
let imgSize = imges[0];
// let keywords = localStorage.getItem('keywords') !== null ? localStorage.getItem('keywords').indexOf('[') >= 0 ? JSON.parse(localStorage.getItem('keywords')) : localStorage.getItem('keywords')  : '';
let keywords = [];

/* chrome.browserAction.onClicked.addListener(function (tabs) {
    console.log('hehe');
}); */

chrome.storage.sync.get(['keywords'], function(items) {
    let keywordsObj = JSON.parse(items.keywords);
    for (let elt of keywordsObj) {
        console.log(elt.tag);
        keywords.push(elt.tag);
    }
});

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (msg.text === 'changeSize') {
        if (imgSize === imges[0]) {
            imgSize = imges[1]
        }
        else if (imgSize === imges[1]) {
            imgSize = imges[0];
        }
    }
});

/* chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    if (msg.text === 'toggleKeyword') {
        console.log(msg.keywords);
        localStorage.setItem('keywords', JSON.stringify(msg.keywords));
        keywords = JSON.parse(localStorage.getItem('keywords'));
    }
}); */

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
    console.log(keywords.length);
    let chars = '';
    let indexer = 0;
    let count0 = 0;
    if (msg.text === 'twitch') {
        let indexer = 0;
        setInterval(() => {
            if (document.getElementsByClassName('text-fragment').length > 0) {
                omegaluler();
            }
        }, 1500);
        function omegaluler() {
            // for (elt of document.getElementsByClassName('chat-line__message') ) { if (elt.childNodes[1].textContent.indexOf('bot') >= 0) { console.log('bot found', elt.childNodes[1].textContent) } }
            for (let elt of document.getElementsByClassName('text-fragment')) {
                if (elt.childNodes[0].tagName === 'SPAN' && elt.parentNode.childNodes[1].textContent.indexOf('bot') === -1 ) {
                    if (elt.childNodes[0].innerHTML.indexOf('bttv-emote-tooltip-wrapper') === -1 && elt.childNodes[0].textContent.indexOf('<') === -1 && elt.childNodes[0].textContent.indexOf('>') === -1) {
                        let newString = '';
                        if (keywords.length > 0) {
                            for (let keyword of keywords) {
                                // console.log(keyword);
                                let regExp = new RegExp(`\\b${keyword}\\b`);
                                if (regExp.test(elt.innerHTML) === true) {
                                    chars = [...elt.innerHTML];
                                    let charsText = [...elt.textContent];
                                    let count = 0;
                                    for (let specChar of charsText) {
                                        console.log(specChar);
                                        // Find o, then regExp test a sliced string of where the o is
                                        if (specChar.toLowerCase() === 'o') {
                                            console.log('hehehehewawasdddddddddddddddddddddddddd');
                                            chars[count] = imgSize;
                                        }
                                        count++;
                                    }
                                    for (let elt of chars) { 
                                        newString+= elt 
                                    }
                                    elt.innerHTML = newString;
                                }
                            }
                        } else {
                            let lowerCaseElt = elt.innerHTML.toLowerCase();
                            if (lowerCaseElt.indexOf('o') > -1) {
                                chars = [...elt.innerHTML];
                                let charsText = [...elt.textContent];
                                let count = 0;
                                for (let specChar of charsText) {
                                    if (specChar.toLowerCase() === 'o') {
                                        chars[count] = imgSize;
                                    }
                                    count++;
                                }
                                for (let elt of chars) { 
                                    newString+= elt 
                                }
                                elt.innerHTML = newString;
                            }
                        }
                    } else {
                        // console.log('bttv emote found', elt.childNodes[0]);
                    }
                } else {
                    if (elt.parentNode.childNodes[1].textContent.indexOf('bot') === -1) {
                        let lowerCaseElt = elt.innerHTML.toLowerCase();
                        let newString = '';
                        if (keywords.length > 0) {
                            for (let keyword of keywords) {
                                let regExp = new RegExp(`\\b${keyword}\\b`);
                                if (regExp.test(elt.innerHTML) === true) {
                                    chars = [...elt.innerHTML];
                                    let charsText = [...elt.textContent];
                                    let count = 0;
                                    for (let specChar of charsText) {
                                        console.log(specChar);
                                    // Find o, then regExp test a sliced string of where the o is
                                        if (specChar.toLowerCase() === 'o') {
                                            console.log('hehehehewawasdddddddddddddddddddddddddd');
                                            chars[count] = imgSize;
                                        }
                                        count++;
                                    }
                                    for (let elt of chars) { 
                                        newString+= elt 
                                    }
                                    elt.innerHTML = newString;
                                }
                            }
                        } else if (lowerCaseElt.indexOf('o') > -1) {
                            chars = [...elt.innerHTML];
                            let charsText = [...elt.textContent];
                            let count = 0;
                            for (let specChar of charsText) {
                                if (specChar.toLowerCase() === 'o') {
                                    chars[count] = imgSize;
                                }
                                count++;
                            }
                            for (let elt of chars) { 
                                newString+= elt 
                            }
                            elt.innerHTML = newString;
                        }
                    }
                }
            }
        }
    }
});